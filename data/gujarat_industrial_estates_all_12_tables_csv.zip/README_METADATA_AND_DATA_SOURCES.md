# Gujarat Industrial Estates Property Dynamics Study
## 12 Core Database Tables Export Archive

**Export Generated (UTC):** 2026-10-03T07:31:27.512796Z
**Jurisdiction:** State of Gujarat, India
**Empirical Window:** 2012 – 2025 Panel

---

### Master Table Registry & Data Sources

#### 01. `01_states.csv` (states)
- **Display Title:** States Master
- **Description:** Spatial root entity representing the State jurisdiction.
- **PRIMARY DATA SOURCE:** Census of India / Government of Gujarat official administrative division code registry.
- **Primary Key:** `state_id`
- **Relational Keys:** `None (Root Entity)`

#### 02. `02_districts.csv` (districts)
- **Display Title:** Districts Master (32 Districts)
- **Description:** Second-tier administrative division encompassing all industrial districts in Gujarat.
- **PRIMARY DATA SOURCE:** Revenue Department, Government of Gujarat & GIDC Divisional Office geographical hierarchy.
- **Primary Key:** `district_id`
- **Relational Keys:** `state_id -> states(state_id)`

#### 03. `03_subdistricts_talukas.csv` (subdistricts_talukas)
- **Display Title:** Subdistricts & Talukas (250 Talukas)
- **Description:** Tehsils and Talukas within each district hosting industrial estates.
- **PRIMARY DATA SOURCE:** Gujarat Land Revenue Code, Taluka Panchayat administrative records, and GIDC regional maps.
- **Primary Key:** `taluka_id`
- **Relational Keys:** `district_id -> districts(district_id)`

#### 04. `04_neighborhoods_jurisdictions.csv` (neighborhoods_jurisdictions)
- **Display Title:** Neighborhoods & Tax Jurisdictions
- **Description:** Local municipal zones, village panchayats, and tax jurisdictions surrounding industrial estates.
- **PRIMARY DATA SOURCE:** Urban Development Authorities (AUDA, VUDA, SUDA), Municipal Tax Records, and GIDC statutory notified zones.
- **Primary Key:** `neighborhood_id`
- **Relational Keys:** `taluka_id -> subdistricts_talukas(taluka_id)`

#### 05. `05_industrial_parks.csv` (industrial_parks)
- **Display Title:** Industrial Parks & GIDC Estates (312 Estates)
- **Description:** Comprehensive catalog of all 312 GIDC government industrial estates and sanctioned private industrial parks/SEZs across Gujarat.
- **PRIMARY DATA SOURCE:** GIDC Official Portal (gidc.gujarat.gov.in), Gujarat State Industrial Policy (2015/2020), Sanctioned Private Industrial Parks under Govt. Resolution (G.R. dated 21/04/2015), and OpenStreetMap spatial geocoding.
- **Primary Key:** `park_id`
- **Relational Keys:** `taluka_id -> subdistricts_talukas(taluka_id)`

#### 06. `06_anchor_facilities.csv` (anchor_facilities)
- **Display Title:** Anchor Facilities & Mega Plants
- **Description:** Major anchor manufacturing facilities, OEM plants, and tier-0 industrial enterprises.
- **PRIMARY DATA SOURCE:** Vibrant Gujarat Global Summit MoUs, Comptroller and Auditor General (CAG) audit reports on industrial development, Environmental Clearance DPR filings, and corporate press releases.
- **Primary Key:** `anchor_id`
- **Relational Keys:** `park_id -> industrial_parks(park_id)`

#### 07. `07_park_lifecycle_events.csv` (park_lifecycle_events)
- **Display Title:** Park Lifecycle Milestones (DiD Windows)
- **Description:** Chronological development milestones defining Pre/Post treatment event windows for econometric estimation.
- **PRIMARY DATA SOURCE:** State Gazette Notifications, GIDC land acquisition awards, Chief Inspector of Factories commissioning permits, and GPCB compliance filings.
- **Primary Key:** `event_id`
- **Relational Keys:** `park_id -> industrial_parks(park_id)`

#### 08. `08_park_annual_metrics.csv` (park_annual_metrics)
- **Display Title:** Park Annual Operational & Environmental Metrics
- **Description:** Multi-year panel tracking economic occupancy, built-up FSI utilization, CEPI environmental pollution scores, and PM2.5 levels.
- **PRIMARY DATA SOURCE:** Gujarat Pollution Control Board (GPCB) Comprehensive Environmental Pollution Index (CEPI) monitoring reports, GIDC annual physical audits, and Central Pollution Control Board (CPCB) air quality archives.
- **Primary Key:** `metric_id`
- **Relational Keys:** `park_id -> industrial_parks(park_id)`

#### 09. `09_clean_commercial_nodes.csv` (clean_commercial_nodes)
- **Display Title:** Clean Commercial Benchmark Nodes
- **Description:** IT parks, financial SEZs, and regional shopping nodes serving as the clean control group to disentangle industrial stigma from general commercial noise.
- **PRIMARY DATA SOURCE:** GIFT City SEZ Authority, Commercial Real Estate Registry (RERA Gujarat), SG Highway High-Street Planning Audits, and Taylor et al. econometric methodology.
- **Primary Key:** `node_id`
- **Relational Keys:** `taluka_id -> subdistricts_talukas(taluka_id)`

#### 10. `10_properties.csv` (properties)
- **Display Title:** Properties & Parcel Spatial Attributes
- **Description:** Tracked residential and commercial land parcels, apartments, and houses across discrete spatial distance buffers.
- **PRIMARY DATA SOURCE:** Sub-Registrar Offices (Revenue Department), Gujarat Real Estate Regulatory Authority (GUJRERA) project filings, and GIS Hedonic buffer radial calculations.
- **Primary Key:** `property_id`
- **Relational Keys:** `neighborhood_id -> neighborhoods_jurisdictions, nearest_park_id -> industrial_parks, nearest_clean_commercial_id -> clean_commercial_nodes`

#### 11. `11_property_transactions.csv` (property_transactions)
- **Display Title:** Property Transactions & Pricing Panel (4,000 Sales)
- **Description:** Multi-year micro-level sale observations tracking real open-market prices against registered statutory circle rates (Jantar) from 2012 to 2025.
- **PRIMARY DATA SOURCE:** Inspector General of Registration (IGR Gujarat) stamped transaction registry, Ready Reckoner / Jantar annual rate sheets (2012–2025), and National Housing Bank (NHB) RESIDEX verification.
- **Primary Key:** `transaction_id`
- **Relational Keys:** `property_id -> properties(property_id)`

#### 12. `12_did_panel_designations.csv` (did_panel_designations)
- **Display Title:** Difference-in-Differences (DiD) Variable Matrix
- **Description:** Econometric treatment, control, and event-study interaction term matrix formatted for estimation.
- **PRIMARY DATA SOURCE:** Econometric formulation based on Taylor et al. spatial gradient methodology and Devanshu Arora Difference-in-Differences research specification.
- **Primary Key:** `designation_id`
- **Relational Keys:** `transaction_id -> property_transactions(transaction_id)`

---

### Usage in Econometric & Statistical Packages

1. **Python / Pandas:**
   ```python
   import pandas as pd
   # Read CSV skipping the commented metadata preamble lines starting with '#'
   df_parks = pd.read_csv('05_industrial_parks.csv', comment='#')
   df_transactions = pd.read_csv('11_property_transactions.csv', comment='#')
   ```

2. **R / tidyverse:**
   ```R
   library(readr)
   transactions <- read_csv('11_property_transactions.csv', comment = '#')
   parks <- read_csv('05_industrial_parks.csv', comment = '#')
   ```

3. **Stata:**
   ```stata
   import delimited using 11_property_transactions.csv, clear
   ```